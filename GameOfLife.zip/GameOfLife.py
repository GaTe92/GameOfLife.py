# by Kadir Eren Unal and Gabriel Teuchert

import random as rd

width = 5
height = 5
dead_state = []
board_state = [
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 0, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1]
]


def DState(dh, dw):  # initialize input
    dstate = []
    zero = [0] * dw
    for i in range(dh):
        dstate.append(zero)
    dstate = [sublist[:] for sublist in dstate]  # no sublists in list
    return dstate


def RState(rh, rw):  # randomize input matrix
    rstate = DState(rh, rw)
    for i in range(rh):
        for ii in range(rw):
            random_number = rd.random()
            if random_number >= 0.5:
                rstate[i][ii] = 0
            else:
                rstate[i][ii] = 1
    return rstate


def Render(state, sh, sw):  # output creator
    plot = ["-------\n"]
    for i in range(sh):
        plot.append("|")
        for ii in range(sw):
            if state[i][ii] == 0:  # 0 or dead state equals space
                plot.append(" ")
            else:
                plot.append("#")  # 1 or live state equals hashtag
        plot.append("|\n")
    plot.append("-------")
    print(''.join(plot))


def RulesOfLive(cstate, sum):            # cellstate True = live ; cellstate False = dead
    if sum <= 1 and cstate is True:
        return cstate is False
    if sum <= 3 and cstate is True:
        return cstate is True
    if sum > 3:
        return cstate is False
    if sum == 3 and cstate is False:
        return cstate is True


def NextBordState(state, nh, nw):
    kernel = []
    nstate = DState(nh, nw)
    cellstate = True
    for i in range(nh):
        for ii in range(nw):
            if state == 1:
                cellstate = True
            else:
                cellstate = False
            for x in range(i - 1, i + 1):
                for y in range(ii - 1, ii + 1):
                    if (x, y >= 0) and (x, y <= 5):
                        kernel.append(state[x][y])
            cellstate = RulesOfLive(cellstate, sum(kernel))
            if cellstate is True:
                nstate[i][ii] = 1
            else:
                nstate[i][ii] = 0
    return nstate


random_state = RState(height, width)  # create an instance
Render(random_state, height, width)  # create plot
next_state = NextBordState(random_state, height, width)
Render(next_state, height, width)

